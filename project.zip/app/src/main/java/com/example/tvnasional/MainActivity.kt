package com.example.tvnasional

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

// ---------- Model ----------
data class Program(val time: String, val title: String)

data class Channel(
    val name: String,
    val streamUrl: String, // GANTI dengan URL HLS (.m3u8) resmi/berlisensi
    val schedule: List<Program>
)

// ---------- Data contoh (nanti ganti dengan Retrofit ke API kamu) ----------
val sampleChannels = listOf(
    Channel(
        "BeeVision 1",
        "https://devstreaming-cdn.apple.com/videos/streaming/examples/img_bipbop_adv_example_fmp4/master.m3u8",
        listOf(
            Program("06:00", "Berita Pagi"),
            Program("08:00", "Kuliner Nusantara"),
            Program("12:00", "Berita Siang"),
            Program("19:00", "Sinetron Prime Time")
        )
    ),
    Channel(
        "BeeVision 2",
        "https://devstreaming-cdn.apple.com/videos/streaming/examples/img_bipbop_adv_example_fmp4/master.m3u8",
        listOf(
            Program("07:00", "Kartun Anak"),
            Program("10:00", "Info Sehat"),
            Program("16:00", "Olahraga Hari Ini"),
            Program("20:00", "Film Malam")
        )
    )
)

// ---------- Activity ----------
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { TvApp(sampleChannels) } }
    }
}

// ---------- UI ----------
@Composable
fun TvApp(channels: List<Channel>) {
    var selected by remember { mutableStateOf(channels.first()) }

    Column(Modifier.fillMaxSize().systemBarsPadding()) {
        LivePlayer(selected.streamUrl)

        LazyRow(
            contentPadding = PaddingValues(12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(channels) { ch ->
                FilterChip(
                    selected = ch == selected,
                    onClick = { selected = ch },
                    label = { Text(ch.name) }
                )
            }
        }

        Text(
            "Jadwal ${selected.name}",
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.padding(horizontal = 16.dp)
        )

        LazyColumn(contentPadding = PaddingValues(16.dp)) {
            items(selected.schedule) { p ->
                Row(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                    Text(p.time, Modifier.width(64.dp), style = MaterialTheme.typography.labelLarge)
                    Text(p.title)
                }
            }
        }
    }
}

@Composable
fun LivePlayer(url: String) {
    val context = LocalContext.current
    val player = remember { ExoPlayer.Builder(context).build() }

    LaunchedEffect(url) {
        player.setMediaItem(MediaItem.fromUri(url))
        player.prepare()
        player.playWhenReady = true
    }
    DisposableEffect(Unit) { onDispose { player.release() } }

    AndroidView(
        factory = { PlayerView(it).apply { this.player = player } },
        modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f)
    )
}
