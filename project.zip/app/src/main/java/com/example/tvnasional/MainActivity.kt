package com.example.tvnasional

import android.content.Context
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

// ============================================================
// DAFTAR STASIUN — edit di sini untuk menambah/mengganti stasiun.
// url  = halaman siaran langsung RESMI (dibuka di dalam aplikasi)
// hls  = (opsional) URL .m3u8 berlisensi; jika diisi, diputar dengan ExoPlayer
// ============================================================
data class Station(
    val name: String,
    val group: String,
    val url: String,
    val color: Long,
    val hls: String? = null
)

const val SWASTA = "Televisi Swasta"
const val PUBLIK = "TVRI"

val stations = listOf(
    Station("RCTI", SWASTA, "https://www.rctiplus.com/tv/rcti", 0xFFD32F2F),
    Station("MNCTV", SWASTA, "https://www.rctiplus.com/tv/mnctv", 0xFF1565C0),
    Station("GTV", SWASTA, "https://www.rctiplus.com/tv/gtv", 0xFF2E7D32),
    Station("iNews", SWASTA, "https://www.rctiplus.com/tv/inews", 0xFFEF6C00),
    Station("SCTV", SWASTA, "https://www.vidio.com/live/204-sctv", 0xFF0277BD),
    Station("Indosiar", SWASTA, "https://www.vidio.com/live/205-indosiar", 0xFF6A1B9A),
    Station("Trans TV", SWASTA, "https://www.vidio.com/live", 0xFFC62828),
    Station("Trans7", SWASTA, "https://www.vidio.com/live", 0xFFF9A825),
    Station("Kompas TV", SWASTA, "https://www.vidio.com/live", 0xFF00838F),
    Station("Metro TV", SWASTA, "https://www.vidio.com/live", 0xFF283593),
    Station("tvOne", SWASTA, "https://www.vidio.com/live", 0xFFAD1457),
    Station("ANTV", SWASTA, "https://www.vidio.com/live", 0xFF00695C),
    Station("TVRI Nasional", PUBLIK, "https://tvri.go.id/live", 0xFF1976D2),
    Station("TVRI Sport", PUBLIK, "https://tvri.go.id/live", 0xFF388E3C)
)

// ---------- Activity ----------
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = Color(0xFF0A84FF),
                    secondary = Color(0xFFFFC107)
                )
            ) { BeeVisionApp() }
        }
    }
}

// ---------- Aplikasi ----------
@Composable
fun BeeVisionApp() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("beevision", Context.MODE_PRIVATE) }
    val favs = remember {
        mutableStateListOf<String>().apply { addAll(prefs.getStringSet("fav", emptySet())!!) }
    }
    fun toggleFav(name: String) {
        if (name in favs) favs.remove(name) else favs.add(name)
        prefs.edit().putStringSet("fav", favs.toSet()).apply()
    }

    var tab by remember { mutableIntStateOf(0) }
    var playing by remember { mutableStateOf<Station?>(null) }
    var customView by remember { mutableStateOf<View?>(null) }
    var customCb by remember { mutableStateOf<WebChromeClient.CustomViewCallback?>(null) }

    Box(Modifier.fillMaxSize()) {
        val p = playing
        if (p != null) {
            BackHandler { playing = null }
            PlayerScreen(
                station = p,
                fav = p.name in favs,
                onBack = { playing = null },
                onFav = { toggleFav(p.name) },
                onShowCustom = { v, cb -> customView = v; customCb = cb },
                onHideCustom = { customView = null; customCb = null }
            )
        } else {
            Scaffold(bottomBar = {
                NavigationBar {
                    listOf("Siaran" to "📺", "Favorit" to "⭐", "Tentang" to "ℹ️")
                        .forEachIndexed { i, (label, emoji) ->
                            NavigationBarItem(
                                selected = tab == i,
                                onClick = { tab = i },
                                icon = { Text(emoji) },
                                label = { Text(label) }
                            )
                        }
                }
            }) { pad ->
                Column(Modifier.padding(pad).fillMaxSize()) {
                    Text(
                        "🐝 BeeVision",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(16.dp, 16.dp, 16.dp, 0.dp)
                    )
                    when (tab) {
                        0 -> StationGrid(stations, favs, { playing = it }, ::toggleFav)
                        1 -> {
                            val list = stations.filter { it.name in favs }
                            if (list.isEmpty()) {
                                Box(Modifier.fillMaxSize(), Alignment.Center) {
                                    Text("Belum ada favorit.\nTekan ☆ pada stasiun.")
                                }
                            } else StationGrid(list, favs, { playing = it }, ::toggleFav)
                        }
                        else -> About()
                    }
                }
            }
        }

        // Layar penuh dari pemutar web (tombol fullscreen di video)
        customView?.let { v ->
            BackHandler { customCb?.onCustomViewHidden(); customView = null; customCb = null }
            AndroidView(
                factory = { (v.parent as? ViewGroup)?.removeView(v); v },
                modifier = Modifier.fillMaxSize().background(Color.Black)
            )
        }
    }
}

@Composable
fun StationGrid(
    list: List<Station>,
    favs: List<String>,
    onPlay: (Station) -> Unit,
    onFav: (String) -> Unit
) {
    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        contentPadding = PaddingValues(12.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        list.groupBy { it.group }.forEach { (group, members) ->
            item(span = { GridItemSpan(maxLineSpan) }) {
                Text(
                    group,
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
            items(members) { s ->
                StationCard(s, s.name in favs, { onPlay(s) }, { onFav(s.name) })
            }
        }
    }
}

@Composable
fun StationCard(s: Station, fav: Boolean, onClick: () -> Unit, onFav: () -> Unit) {
    Card(onClick = onClick, modifier = Modifier.fillMaxWidth().height(96.dp)) {
        Box(Modifier.fillMaxSize().background(Color(s.color))) {
            Text(
                s.name,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp,
                modifier = Modifier.align(Alignment.Center)
            )
            Text(
                if (fav) "★" else "☆",
                color = Color.White,
                fontSize = 22.sp,
                modifier = Modifier.align(Alignment.TopEnd).clickable { onFav() }.padding(8.dp)
            )
        }
    }
}

@Composable
fun PlayerScreen(
    station: Station,
    fav: Boolean,
    onBack: () -> Unit,
    onFav: () -> Unit,
    onShowCustom: (View, WebChromeClient.CustomViewCallback) -> Unit,
    onHideCustom: () -> Unit
) {
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("← Kembali") }
            Text(
                station.name,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f).padding(horizontal = 8.dp)
            )
            Text(
                if (fav) "★" else "☆",
                fontSize = 24.sp,
                modifier = Modifier.clickable { onFav() }.padding(8.dp)
            )
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (station.hls != null) HlsPlayer(station.hls)
            else key(station.url) { WebPlayer(station.url, onShowCustom, onHideCustom) }
        }
    }
}

// Pemutar siaran dari halaman resmi stasiun/platform
@Composable
fun WebPlayer(
    url: String,
    onShow: (View, WebChromeClient.CustomViewCallback) -> Unit,
    onHide: () -> Unit
) {
    AndroidView(
        factory = { ctx ->
            WebView(ctx).apply {
                keepScreenOn = true
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.mediaPlaybackRequiresUserGesture = false
                webViewClient = WebViewClient()
                webChromeClient = object : WebChromeClient() {
                    override fun onShowCustomView(v: View, cb: CustomViewCallback) = onShow(v, cb)
                    override fun onHideCustomView() = onHide()
                }
                loadUrl(url)
            }
        },
        modifier = Modifier.fillMaxSize(),
        onRelease = { it.destroy() }
    )
}

// Pemutar HLS langsung (untuk stasiun yang punya URL .m3u8 berlisensi)
@Composable
fun HlsPlayer(url: String) {
    val context = LocalContext.current
    val player = remember { ExoPlayer.Builder(context).build() }
    LaunchedEffect(url) {
        player.setMediaItem(MediaItem.fromUri(url))
        player.prepare()
        player.playWhenReady = true
    }
    DisposableEffect(Unit) { onDispose { player.release() } }
    AndroidView(
        factory = { PlayerView(it).apply { this.player = player; keepScreenOn = true } },
        modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f)
    )
}

@Composable
fun About() {
    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("BeeVision", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Text("Versi 1.0")
        Text(
            "Siaran dibuka dari layanan resmi masing-masing stasiun " +
                "(RCTI+, Vidio, TVRI). Hak siar dan iklan tetap milik stasiun terkait."
        )
    }
}
